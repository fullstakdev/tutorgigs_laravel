<?php



namespace App\Models;



use Illuminate\Database\Eloquent\Model;



class Admin extends Model

{

     protected $table = 'gig_admins';

     public $timestamps = false;

    

}

