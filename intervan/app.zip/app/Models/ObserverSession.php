<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ObserverSession extends Model
{
     protected $table = 'observer_sessions_list';
     public $timestamps = false;
    
}
