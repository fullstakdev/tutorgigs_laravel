<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Tutor extends Model
{
     protected $table = 'gig_teachers';
     public $timestamps = false;
    
}
