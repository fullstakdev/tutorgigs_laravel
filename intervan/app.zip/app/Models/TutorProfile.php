<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TutorProfile extends Model
{
     protected $table = 'tutor_profiles';
     public $timestamps = false;
    
}
