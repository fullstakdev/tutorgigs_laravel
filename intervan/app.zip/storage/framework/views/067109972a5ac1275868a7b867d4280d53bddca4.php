<?php $__env->startSection('css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/custom_css/custom.css')); ?>">
<style>
  #session-table_filter{ float: right; }
  .filter_table a {
      margin-top: 1.8rem;
  }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="d-flex flex-column-fluid" style="margin-top: 2%">
 <!--begin::Container-->
 <div class="container">
  <div class="card card-custom gutter-b example example-compact">
   <div class="card-header">
    <h3 class="card-title"><i class="fa fa-plus-circle"></i>Sessions List</h3>
    <div class="card-toolbar">
     <div class="example-tools justify-content-center">
       <a href="<?php echo e(url('create_session')); ?>" class="btn btn-warning">Create Session</a>
     </div>
    </div>
   </div>
    <div class="card-body">
      <?php if(Session::has('success')): ?>
        <div class="alert alert-success">
          <i class="fas fa-check-circle"></i> <?php echo e(Session::get('success')); ?>

        </div>
      <?php endif; ?>
      <div class="row">
        <div class="col-sm-12 col-md-9 ">
          <?php echo $__env->make('includes.session_filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-sm-12 col-md-3">
          <table class="table-responsive filter_table">
            <tbody style="float:right;">
              <tr>
                <td><a href="<?php echo e(url('session/calendar-view')); ?>" class="btn btn-primary">Calendar View</a></td>
                <td><a href="<?php echo e(url('session/list')); ?>" class="btn btn-primary">List View</a></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <table class="table" id="session-table">
       <thead>
         <th>Sr#</th>
         <th>Start Date</th>
         <th>End Date</th>
         <th>District</th>
         <th>School</th>
         <th>Grade</th>
         <th>Lessons</th>
         <th>Type</th>
         <th>Action</th>
       </thead>
       <tbody>
        <?php $__currentLoopData = $repeatSessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rp_se): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e(date_format(date_create($rp_se->start_date), 'F d,Y')); ?></td>
            <td><?php echo e(date_format(date_create($rp_se->end_date), 'F d,Y')); ?></td>
            <td><?php echo e($rp_se->district->district_name); ?></td>
            <td><?php echo e($rp_se->school->SchoolName); ?></td>
            <td><?php echo e($rp_se->grade->name); ?></td>
            <td>
              <a href="javaScript:;" data-toggle="modal" data-target="#lesson_modal_<?php echo e($rp_se->id); ?>">View Lesson</a>
              <!-- Modal -->
              <div class="modal fade" id="lesson_modal_<?php echo e($rp_se->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title">Lessons Detail</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true" style="display:block!important">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body">
                      <ul style="list-style:none">
                        <?php $__currentLoopData = $rp_se->lesson->lessons(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li>Day <?php echo e($loop->iteration); ?>: <?php echo e($l->name); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </ul>
                    </div>
                    
                  </div>
                </div>
              </div>
            </td>
            <td><?php echo e($rp_se->getType()); ?></td>
            <td>
              <a href="<?php echo e(route('repeat.sessions.edit',$rp_se->id)); ?>" class="btn btn-info btn-sm">Edit</a>
              <a href="<?php echo e(route('repeat.sessions.delete',$rp_se->id)); ?>" class="btn btn-danger btn-sm" onclick="if(!confirm('Are you sure to delete?')){ return false; }">Delete</a>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $nosessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rp_se): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e(date_format(date_create($rp_se->start_date), 'F d,Y')); ?></td>
            <td><?php echo e(date_format(date_create($rp_se->start_date), 'F d,Y')); ?></td>
            <td><?php echo e($rp_se->district->district_name); ?></td>
            <td><?php echo e($rp_se->school->SchoolName); ?></td>
            <td><?php echo e($rp_se->grade->name); ?></td>
            <td>
              <a href="javaScript:;" data-toggle="modal" data-target="#lesson_modal_no<?php echo e($rp_se->id); ?>">View Lesson</a>
              <!-- Modal -->
              <div class="modal fade" id="lesson_modal_no<?php echo e($rp_se->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title">Lessons Detail</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true" style="display:block!important">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body">
                      <?php echo e(isset($rp_se->lesson->name)?$rp_se->lesson->name:''); ?>

                    </div>
                    
                  </div>
                </div>
              </div>
            </td>
            <td>Not Repeat</td>
            <td>
              <a href="<?php echo e(route('session.edit',$rp_se->id)); ?>" class="btn btn-info btn-sm">Edit</a>
              <a href="<?php echo e(route('delete.no_repeat.session',$rp_se->id)); ?>" class="btn btn-danger btn-sm" onclick="if(!confirm('Are you sure to delete?')){ return false; }">Delete</a>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </tbody>
      </table>
    </div>
   </div>
   
  </div>
  <!--end::Bottom-->
  
 </div>
 
</div>
<!--end::Container-->
</div>
<!--end::Content-->

 <?php $__env->stopSection(); ?>
 <?php $__env->startSection('js'); ?>
  <?php echo $__env->make('includes.distric_school_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <script src="<?php echo e(asset('assets/plugins/custom/datatables/datatables.bundle.js')); ?>"></script>
  <script>
    $("#session-table").dataTable();
  </script>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('template.container', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/codyivxh/public_html/intervan/resources/views/session/repeat_session.blade.php ENDPATH**/ ?>