<style>
  .select2-container--default .select2-selection--single .select2-selection__rendered .select2-selection__clear:after{ display:none }
</style>
<form method="GET" action="">
        <div class="form-row">
          <div class="form-group col-sm-12 col-md-3">
            <label class="label-control">District</label>
            <select class="form-control" name="district" id="district">
              <option value="">--Choose District--</option>
              <?php $__currentLoopData = $district_wise_school_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($d->id); ?>" <?php echo e(request()->get('district')==$d->id?'selected':''); ?>><?php echo e($d->district_name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
          <div class="form-group col-sm-12 col-md-3">
            <label class="label-control">School</label>
            <select class="form-control" name="school" id="d_school">
              <option value="">--Choose School--</option>
              <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <option value="<?php echo e($s->SchoolId); ?>" <?php echo e(request()->get('school')==$s->SchoolId?'selected':''); ?>><?php echo e($s->SchoolName); ?></option>
                }
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
          <div class="form-group col-sm-12 col-md-3">
            <label class="label-control">Grade</label>
            <select class="form-control" name="grade" id="grade_id">
              <option value="">--Choose Grade--</option>
              <?php $__currentLoopData = $grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($g->id); ?>" <?php echo e(request()->get('grade')==$g->id?'selected' : ''); ?>><?php echo e($g->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
          <div class="form-group col-md-2">
            <button type="submit" class="btn btn-info" style="margin-top: 1.9rem;">Filter</button>
          </div>

        </div>
      </form><?php /**PATH /home/codyivxh/public_html/intervan/resources/views/includes/session_filter.blade.php ENDPATH**/ ?>