<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('public/css/mobiscroll.jquery.min.css')); ?>" rel="stylesheet" />
<link href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/select2/3.5.2/select2.min.css">
<style type="text/css">
 .form-group label {
     font-size: 15px;
     font-weight: 600;
     color: #3F4254;
 }
 label.radio,label.checkbox {
     font-weight: 400;
     font-size: 1rem;
 }
 /*select,input[type="text"],.select2-selection__rendered {
     min-height: 45px;
 }*/
 super.req{ color: red; }
 /*Select 2 Option CSS**/

  .select2-container .select2-choice{ 
  background:unset!important;
  display: block;
      width: 100%;
      height: calc(1.5em + 1.3rem + 2px);
      padding: 0.65rem 1rem;
      font-size: 1rem;
      font-weight: 400;
      line-height: 1.5;
      color: #3F4254;
      background-color: #ffffff;
      background-clip: padding-box;
      border: 1px solid #E4E6EF;
      border-radius: 0.42rem;
      -webkit-box-shadow: none;
      box-shadow: none;
      -webkit-transition: border-color 0.15s ease-in-out, -webkit-box-shadow 0.15s ease-in-out;
      transition: border-color 0.15s ease-in-out, -webkit-box-shadow 0.15s ease-in-out;
      transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
      transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out, -webkit-box-shadow 0.15s ease-in-out;
  }
  .select2-container .select2-choice .select2-arrow{
      background:unset!important;
      border-left:unset!important;
  }
  .select2-container-multi .select2-choices{
      display: block;
      width: 100%;
      font-size: 1rem;
      font-weight: 400;
      color: #3F4254;
      background-color: #ffffff;
      background-clip: padding-box;
      border: 1px solid #E4E6EF;
      border-radius: 0.42rem;
      -webkit-box-shadow: none;
      box-shadow: none;
      -webkit-transition: border-color 0.15s ease-in-out, -webkit-box-shadow 0.15s ease-in-out;
      transition: border-color 0.15s ease-in-out, -webkit-box-shadow 0.15s ease-in-out;
      transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
      transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out, -webkit-box-shadow 0.15s ease-in-out;
  }
  .select2-search-field input{
    min-height: 36px;
  }
  .mbsc-calendar-cell.mbsc-calendar-day > div:first-child{ display:none; }

 /**END*/
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex flex-column-fluid" style="margin-top: 2%">
 <!--begin::Container-->
 <div class="container">
  <div class="card card-custom gutter-b example example-compact">
   <div class="card-header">
    <h3 class="card-title"><i class="fa fa-plus-circle"></i>Edit Repeat Session</h3>
    <div class="card-toolbar">
     <div class="example-tools justify-content-center">
      <span class="example-toggle" data-toggle="tooltip" title="" data-original-title="View code"></span>
      <span class="example-copy" data-toggle="tooltip" title="" data-original-title="Copy code"></span>
     </div>
    </div>
   </div>
   <!--begin::Form-->
   <form action="<?php echo e(route('repeat.sessions.update',$repeat_session->id)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="card-body">
      <?php if(Session::has('success')): ?>
        <div class="alert alert-success">
          <i class="fas fa-check-circle"></i> <?php echo e(Session::get('success')); ?>

        </div>
      <?php endif; ?>
      <?php if($errors->any()): ?>
        <div class="row">
          <div class="col-sm-8 alert alert-danger">
            <?php echo e($errors->first()); ?>

          </div>
        </div>
      <?php endif; ?>
     <div class="row">
      <div class="col-sm-6">
       <div class="form-group">
        <label for="exampleSelectd">District<super class="req">*</super></label>
        <select class="col-sm-12" name="district" id="district" required>
         <option value="">Select a district</option>
         <?php $__currentLoopData = $district_wise_school_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <option value="<?php echo $district->id; ?>" <?php echo e($district->id==$repeat_session->district_id?'selected': ''); ?>><?php echo e($district->district_name); ?></option>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         
        </select>
       </div>
      </div>
      <div class="col-sm-6">
       <div class="form-group">
        <label for="exampleSelectd">School<super class="req">*</super></label>
        <select  id="d_school" name="master_school"  class="col-sm-12" required>
         <option value="">Select a school</option>
         <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($school->SchoolId); ?>" <?php echo e($school->SchoolId==$repeat_session->school_id?'selected':''); ?>><?php echo e($school->SchoolName); ?></option>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        
       </div>
      </div>
     </div>
     <div class="row">
      <div class="col-sm-6">
       <div class="form-group">
        <label for="exampleSelectd">Grade<super class="req">*</super></label>
        <select class="col-sm-12" name="grade" id="grade_id" required>
         <option value="">Select a grade</option>
         <?php $__currentLoopData = $grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <option value="<?php echo e($grade->id); ?>" <?php echo e($grade->id==$repeat_session->grade_id?'selected':''); ?>><?php echo e($grade->name); ?></option>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
       </div>
      </div>
      <div class="col-sm-6">
       <div class="form-group" id="main_kt_select2_9">
        <label for="exampleSelectd">Students<super class="req">*</super></label>
        <input type="text" class="col-sm-12" id="kt_select2_9" name="student"  multiple="multiple" required>
        <?php if($repeat_session->student_per_session>0): ?>
        <div id="student_per_session_div">
          <label for="exampleSelectd">Student Per Session<super class="req">*</super></label>
          <select name="students_per_session" class="form-control">
            <option value="1" <?php echo e($repeat_session->student_per_session==1?'selected' : ''); ?>>1</option>
            <option value="2" <?php echo e($repeat_session->student_per_session==2?'selected' : ''); ?>>2</option>
            <option value="3" <?php echo e($repeat_session->student_per_session==3?'selected' : ''); ?>>3</option>
            <option value="4" <?php echo e($repeat_session->student_per_session==4?'selected' : ''); ?>>4</option>
            <option value="5" <?php echo e($repeat_session->student_per_session==5?'selected' : ''); ?>>5</option>
            <option value="6" <?php echo e($repeat_session->student_per_session==6?'selected' : ''); ?>>6</option>
            <option value="7" <?php echo e($repeat_session->student_per_session==7?'selected' : ''); ?>>7</option>
            <option value="8" <?php echo e($repeat_session->student_per_session==8?'selected' : ''); ?>>8</option>
            <option value="9" <?php echo e($repeat_session->student_per_session==9?'selected' : ''); ?>>9</option>
            <option value="10" <?php echo e($repeat_session->student_per_session==10?'selected' : ''); ?>>10</option>
          </select>
        </div>
        <?php endif; ?>
       </div>
      </div>
     </div>
     
     
     <div class="row">
      <div class="col-sm-6">
       <div class="form-group">
        <label for="exampleSelectd">Tutor/Instructor Certification Required</label>
        <select class="form-control" name="certificate_required" id="certificate_required" onchange="javascript: if(this.value == 1) $('#certificate').show('slow'); else $('#certificate').hide('slow');">
         <option value="0">No</option>
         <option value="1">Yes</option>
         
        </select>
       </div>
      </div>
      <div class="col-sm-6" id="course-div-sh">
       <div class="form-group">
        <label for="lesson_id">Courses<super class="req">*</super></label>
        <select class="col-sm-12 form-control" id="course_id" name="rule_id" required>
         
         <option value="">Select Course</option>
         <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <option value="<?php echo $course->id; ?>" <?php echo e($course->id==$repeat_session->rule_id?'selected':''); ?>><?php echo $course->title; ?></option>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
       </div>
      </div>
      <?php $as_day = isset($assesment_day->assesment_day) ? $assesment_day->assesment_day : ''; ?>
      <div class="col-sm-6" id="as_id">
        <div class="form-group">
         <label for="lesson_id" style="font-size: 15px;font-weight: 500;">Assesment</label><input type="checkbox" style="margin: 0px 0px 0px 5px;" onclick="var s = this; if($(s).prop('checked')){ $(s).next().show('slow'); }else{ $(s).next().hide('slow'); $(s).next().val(''); }" <?php echo e($as_day != '' ? 'checked' : ''); ?>>
         <select class="col-sm-12 form-control" id="assesment_day" name="assesment_day" style="<?php echo e($as_day==''?'display:none;' : ''); ?>">
          
          <option value="">Select Assessment</option>
          <?php for($i=1; $i<=10; $i++): ?>
            <option value="<?php echo e($i); ?>" <?php echo e($i==$as_day?'selected':''); ?>><?php echo e($i); ?></option>
          <?php endfor; ?>
         </select>
        </div>
      </div>
      <div class="col-sm-12">
       <div class="form-group" id="certificate" style="display:none">
        <label for="exampleSelectd">Choose Certificate</label>
        <div class="checkbox-inline">
         <label class="radio">
          <input type="radio"  name="certificate" value="Bilingual Tutor ( Spanish )">
          <span></span>&nbsp;&nbsp;Bilingual Tutor ( Spanish ) &nbsp;&nbsp;&nbsp;&nbsp;</label>
          <label class="radio">
           <input type="radio" name="certificate" value="Certified Teacher">
           <span></span>&nbsp;&nbsp;Certified Teacher &nbsp;&nbsp;&nbsp;&nbsp;</label>
           <label class="radio">
            <input type="radio" checked="checked" name="certificate" value="Certified Teacher in ESL">
            <span></span>&nbsp;&nbsp;Certified Teacher in ESL &nbsp;&nbsp;&nbsp;&nbsp;</label>
            <label class="radio">
             <input type="radio" checked="checked" name="certificate" value="Certified Teacher in ESL with Bilingual Tutor ( Spanish )">
             <span></span>&nbsp;&nbsp;Certified Teacher in ESL with Bilingual Tutor ( Spanish ) </label>
             
            </div>
           </div>
          </div>
     </div>
     <div class="row">
         <div class="col-sm-3" id="repeat">
          <div class="form-group">
           <label for="exampleSelectd">Repeat Type</label>
           <select class="form-control " name="repeat_type" onchange="javascript: if(this.value == 'month' || this.value == 'year' || this.value == '2_week' || this.value == '3_week' || this.value=='week_days') { $('#week_days').hide('slow');} ; if(this.value == 'weekly' ) { $('#week_days').show('slow');} ; ">
            <option value="">Select Repeat Type</option>
            <option value="weekly" <?php echo e($repeat_session->repeat_type=="weekly" ? 'selected' : ''); ?>>Weekly</option>
            <option value="week_days" <?php echo e($repeat_session->repeat_type=="week_days" ? 'selected' : ''); ?>>Every Weekday(Monday to Friday)</option>
            <option value="2_week" <?php echo e($repeat_session->repeat_type=="2_week" ? 'selected' : ''); ?>>Every 2 weeks</option>
            <option value="3_week" <?php echo e($repeat_session->repeat_type=="3_week" ? 'selected' : ''); ?>>Every 3 weeks</option>
            <option value="month" <?php echo e($repeat_session->repeat_type=="month" ? 'selected' : ''); ?>>Every Month</option>
            <option value="year" <?php echo e($repeat_session->repeat_type=="year" ? 'selected' : ''); ?>>Every Year</option>
           </select>
          </div>
         </div>
         <div class="col-sm-3">
          <div class="form-group" id="week_days" style="<?php echo e($repeat_session->repeat_type=='weekly' ? 'block' : 'display:none'); ?>">
            <?php $days = explode(',',$repeat_session->repeat_days); ?>
           <label for="exampleSelectd">Choose Week Days</label>
           <div class="checkbox-inline">
            <label class="checkbox">
             <input type="checkbox"  name="days[Sunday]" <?php echo e(in_array("Sunday",$days) ? 'checked' : ''); ?>>
             <span></span>Sun
            </label>
            <label class="checkbox">
              <input type="checkbox" name="days[Monday]" <?php echo e(in_array("Monday",$days) ? 'checked' : ''); ?>>
              <span></span>Mon
             </label>
             <label class="checkbox">
               <input type="checkbox"  name="days[Tuesday]" <?php echo e(in_array("Tuesday",$days) ? 'checked' : ''); ?>>
               <span></span>Tue
              </label>
              <label class="checkbox">
                <input type="checkbox"  name="days[Wednesday]" <?php echo e(in_array("Wednesday",$days) ? 'checked' : ''); ?>>
                <span></span>Wed
               </label>
              <label class="checkbox">
                <input type="checkbox"  name="days[Thursday]" <?php echo e(in_array("Thursday",$days) ? 'checked' : ''); ?>>
                <span></span>Thu
               </label>
               <label class="checkbox">
                 <input type="checkbox"  name="days[Friday]" <?php echo e(in_array("Friday",$days) ? 'checked' : ''); ?>>
                 <span></span>Fri
                </label>
                <label class="checkbox">
                 <input type="checkbox" name="days[Saturday]" <?php echo e(in_array("Saturday",$days) ? 'checked' : ''); ?>>
                 <span></span>Sat
                </label>
           </div>
          </div>
         </div>
     </div>
     <div class="row">
      <div class="col-sm-6" id="repeat_end_date">
        <div class="form-group">
          <label for="exampleSelectd">Choose Start-End Date<super class="req">*</super></label>
          <div id="repeat_date_cal"></div>
        </div>

        <input type="hidden" name="start_date" id="start_date" value="<?php echo e(date('m/d/Y',strtotime($repeat_session->start_time))); ?>" />
       <input type="hidden" name="end_date" id="end_date" value="<?php echo e(date('m/d/Y',strtotime($repeat_session->end_date))); ?>" />
       
       
      </div>
      <div class="col-sm-3">
       <div class="form-group">
        <label for="exampleSelectd">Time<super class="req">*</super></label>
        <div class="input-group input-group-solid date">
         <input type="time" name="time" class="form-control form-control-solid" placeholder="Select date &amp; time" value="<?php echo e($repeat_session->start_time); ?>" />
        
          <!-- <span class="input-group-text input-group-append">
           <i class="ki ki-clock"></i>
          </span> -->
        </div>
       </div>
      </div>
      <div class="col-sm-6">
       <div class="form-group">
        <label for="exampleSelectd">Duration<super class="req">*</super></label>
        <select class="form-control" id="duration_id" name="duration" required onchange="showPaymentRate(this.value)">
             <?php for($i=15; $i<=60; $i=$i+5): ?>
              <option value="<?php echo e($i); ?>" <?php echo e($i==$repeat_session->session_duration?'selected':''); ?>><?php echo e($i); ?></option>
             <?php endfor; ?>
       </select>
      </div>
     </div>
      <div class="col-sm-6" id="payment_rate_div">
       <div class="form-group">
        <label for="exampleSelectd">Payment Overview<super class="req"></super></label>
        <input type="number" min="0.00" id="payment_rate" name="payment_rate" class="form-control" value="<?php echo e($repeat_session->payment_rate); ?>" required>
      </div>
     </div>
    </div>
    <?php $sp_days = $repeat_session->sp_holidays != NULL ? $repeat_session->sp_holidays : ''; ?>
    <div class="row" id="sp_h_div">
      <div class="col-sm-6">
        <div class="form-group">
            <label for="lesson_id" style="font-size: 15px;font-weight: 500;">Holiday Date<super class="req">*</super></label><input id="holiday_checkbox" type="checkbox" style="margin: 0px 0px 0px 5px;" onclick="var s = this; if($(s).prop('checked')){ $(s).next().show('slow'); }else{ $(s).next().hide('slow'); }" <?php echo e($sp_days !='' ? 'checked' : ''); ?>>
          <div id="sp_holiday_cal" style="<?php echo e($sp_days =='' ? 'display:none' : ''); ?>"></div>
        </div>
      </div>
       <input type="hidden" name="sp_holiday" id="sp_holiday" value="<?php echo e($repeat_session->sp_holidays); ?>">
    </div>
   
    
   
          
          
              
             </div>
             <div class="card-footer">
              <button type="submit" class="btn btn-primary mr-2"  onclick="SetHoliday()">Submit</button>
              <button type="reset" class="btn btn-secondary">Cancel</button>
             </div>
            </form>
            <!--end::Form-->
           </div>
           
          </div>
          <!--end::Bottom-->
          
         </div>
         
        </div>
        <!--end::Container-->
       </div>
       <!--end::Content-->
       <?php $__env->stopSection(); ?>
       <?php $__env->startSection('js'); ?>
       <script src="<?php echo e(asset('public/js/mobiscroll.jquery.min.js')); ?>"></script>
       <script>
           
           mobiscroll.setOptions({
               theme: 'ios',
               themeVariant: 'light'
           });

           $(function () {

               $('#sp_holiday_cal').mobiscroll().datepicker({
                   controls: ['calendar'],
                   display: 'inline',
                   rangeSelectMode: 'wizard',
                   select: 'range',
                   showRangeLabels: true,
                   returnFormat: 'iso8601'
               });
               <?php if($sp_days): ?>
                $("#sp_holiday_cal").mobiscroll('setVal', '<?php echo e($sp_days); ?>'.split(','));
               <?php endif; ?>


               $("#repeat_date_cal").mobiscroll().datepicker({
                   controls: ['calendar'],
                   display: 'inline',
                   rangeSelectMode: 'wizard',
                   select: 'range',
                   showRangeLabels: true,
                   returnFormat: 'iso8601'
               });

               $("#repeat_date_cal").mobiscroll('setVal', ["<?php echo e(date('Y-m-d',strtotime($repeat_session->start_time))); ?>","<?php echo e(date('Y-m-d',strtotime($repeat_session->end_date))); ?>"]);

           });

           function SetHoliday(){
            if($("#holiday_checkbox").prop('checked')){
              var holiday_val = $('#sp_holiday_cal').mobiscroll('getVal');
              $("#sp_holiday").val(holiday_val);
            }else{
              $("#sp_holiday").val('');
            }

            var strt_end_date = $('#repeat_date_cal').mobiscroll('getVal');
            if(strt_end_date==''){
              window.event.preventDefault();
              window.alert("Please choose start and end date....");
              return false;
            }else if(strt_end_date[1]==null){
              window.event.preventDefault();
              window.alert("Please choose end date....");
              return false;
            }
            $("#end_date").val(strt_end_date[1]);
            $("#start_date").val(strt_end_date[0]);
           }
       </script>
       <!--begin::Page Vendors(used by this page)-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/3.5.2/select2.min.js"></script>
   
       <script src="<?php echo e(asset('assets/plugins/custom/datatables/datatables.bundle.js')); ?>"></script>
       <!-- <script src="<?php echo e(asset('assets/js/pages/crud/forms/widgets/select2.js')); ?>"></script> -->
       <script src="<?php echo e(asset('assets/js/pages/crud/forms/widgets/bootstrap-datetimepicker.js')); ?>"></script>
       <script>
       var test,test2;
       $('#district').change(function () {
       district = $(this).val();
       //  $('#district_school').html('Loading ...');
       
       $.ajax({
       type: "GET",
       url: "<?php echo url('ajax_laoding_data')?>?district="+district+"&action=get_multiple_schools&school_id=",
       success: function (response) {
       $('#d_school').html(response);
       
       },
       async: true
       });
       });
       
       $('#d_school').change(function () {
       school = $(this).val();
       //  $('#district_school').html('Loading ...');
       
       $.ajax({
       type: "GET",
       url: "<?php echo url('ajax_laoding_data')?>?school_id="+school+"&action=get_school_grades&district=",
       success: function (response) {
       $('#grade_id').html(response);
       
       },
       async: true
       });
       });
       
       $('#grade_id').change(function () {
        var grade_id = $(this).val();
        var school_id = $('#d_school').val();
       //  $('#district_school').html('Loading ...');
       
       $.ajax({
       type: "GET",
       url: "<?php echo url('ajax_laoding_data')?>?school_id="+school_id+"&action=get_multiple_students&grade_id="+grade_id,
       success: function (response) {
        $('#kt_select2_9').removeClass('form-control');
       $('#kt_select2_9').html(response);
        test = response;
        var STU_GROUPS = JSON.parse(response);
        multipleGroupSelect(STU_GROUPS);
       },
       async: true
       });
       });

       var select2_array = ['#district',"#d_school","#grade_id","#lesson_id"];
       for (var v in select2_array) {
        $(select2_array[v]).select2({
         allowClear: true,
         width: 'resolve',
         dropdownAutoWidth: true
        });
       }
       $(".timepicker-div").timepicker();
       $(".start_date_datepicker").datepicker();
       function multipleGroupSelect(STU_GROUPS) {
         $('#kt_select2_9').select2({
             multiple: true,
             placeholder: "Select Students...",
             data: STU_GROUPS,
             query: function(options) {
                if(options.element==undefined){
                  return options.callback({ results: null });
                }
                 var selectedIds = options.element.select2('val');
                 var selectableGroups = $.map(this.data, function(group) {
                     var areChildrenAllSelected = true;
                     $.each(group.children, function(i, child) {
                         if (selectedIds.indexOf(child.id) < 0) {
                             areChildrenAllSelected = false;
                             return false; // Short-circuit $.each()
                         }
                    });
                     return !areChildrenAllSelected ? group : null;
                 });
                 options.callback({ results: selectableGroups });
             }
         }).on('select2-selecting', function(e) {
             var $select = $(this);
             if (e.val == '') {
                 e.preventDefault();
                 $select.select2('data', $select.select2('data').concat(e.choice.children));
                 $select.select2('close');
              }
              if(e.object.text==="All Student Group"){

                var div = document.createElement("div");
                div.id="student_per_session_div";
                div.style.marginTop ="5px";
                div.innerHTML = ' <label for="exampleSelectd">Student Per Session<super class="req">*</super></label><select name="students_per_session" class="form-control"><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option><option value="6">6</option><option value="7">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option></select>';
                if(!$("#student_per_session_div").length){
                   $("#main_kt_select2_9").append(div);
                }
              }else{
                if($("#student_per_session_div").length){
                   $("#student_per_session_div").remove();
                }
              }

         });
       }
       /*Start Multigroup Student Select*/
       var STU_GROUPS = [
           {
               id: '',
               text: 'All Student Group',
               children: [
                   <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    { id : '<?php echo e($student->id); ?>', text: '<?php echo e($student->first_name); ?>'},
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               ]
           },
       ];
       $('#kt_select2_9').select2({
           multiple: true,
           placeholder: "Select Students...",
           data: STU_GROUPS,

       }).on('select2-selecting', function(e) {
           var $select = $(this);
           if (e.val == '') {
               e.preventDefault();
               $select.select2('data', $select.select2('data').concat(e.choice.children));
               $select.select2('close');
           }
           
           if(e.object.text==="All Student Group"){

             var div = document.createElement("div");
             div.id="student_per_session_div";
             div.style.marginTop ="5px";
             div.innerHTML = ' <label for="exampleSelectd">Student Per Session<super class="req">*</super></label><select name="students_per_session" class="form-control"><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option><option value="6">6</option><option value="7">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option></select>';
             if(!$("#student_per_session_div").length){
                $("#main_kt_select2_9").append(div);
             }
           }else{
             if($("#student_per_session_div").length){
                $("#student_per_session_div").remove();
             }
           }
       });
       window.addEventListener("load",function(){
        $("#kt_select2_9").val("<?php echo e($repeat_session->student_ids); ?>").trigger("change");
       });
       /*End Student Group*/


       </script>
       <?php echo $__env->make('includes.payment_rate_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       <?php $__env->stopSection(); ?>
<?php echo $__env->make('template.container', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/codyivxh/public_html/intervan/resources/views/session/repeat_session_edit.blade.php ENDPATH**/ ?>