<?php $__env->startSection('css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/custom_css/custom.css')); ?>">
<style>
  #session-table_filter{ float: right; }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="d-flex flex-column-fluid" style="margin-top: 2%">
 <!--begin::Container-->
 <div class="container">
  <div class="card card-custom gutter-b example example-compact">
   <div class="card-header">
    <h3 class="card-title"><i class="fa fa-plus-circle"></i>Sessions List</h3>
    <div class="card-toolbar">
     <div class="example-tools justify-content-center">
       <a href="<?php echo e(url('create_session')); ?>" class="btn btn-warning">Create Session</a>
     </div>
    </div>
   </div>
    <div class="card-body">
      <?php if(Session::has('success')): ?>
        <div class="alert alert-success">
          <i class="fas fa-check-circle"></i> <?php echo e(Session::get('success')); ?>

        </div>
      <?php endif; ?>
      <div class="row">
        <div class="col-sm-12 col-md-9">
          <?php echo $__env->make('includes.session_filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-sm-12 col-md-3">
          <table class="table-responsive">
        <tbody style="float:right;">
          <tr>
            <td><a href="<?php echo e(url('session/calendar-view')); ?>" class="btn btn-primary">Calendar View</a></td>
            <td><a href="<?php echo e(url('session/repeat-sessions')); ?>" class="btn btn-primary">Repeat Sessions</a></td>
          </tr>
        </tbody>
      </table>
        </div>
      </div>
      
      
      <table class="table" id="session-table">
       <thead>
         <th>Sr#</th>
         <th>Sess Time</th>
         <th>Sess ID</th>
         <th>District</th>
         <th>School</th>
         <th>Grade</th>
         <th>Virtual Board</th>
         <th>Status</th>
         <th>Action</th>
       </thead>
       <tbody>
        <?php $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e(date_format(date_create($session->ses_start_time), 'F d,Y h:i a')); ?></td>
            <td><?php echo e($session->id); ?></td>
            <td><?php echo e(isset($session->district->district_name)?$session->district->district_name:''); ?></td>
            <td><?php echo e(isset($session->school->SchoolName)?$session->school->SchoolName:''); ?></td>
            <td><?php echo e(isset($session->grade->name)?$session->grade->name:''); ?></td>
            <td><?php echo e($session->curr_active_board); ?></td>
            <td>
              <?php $today = strtotime(date('Y-m-d h:i')); $start = strtotime($session->ses_start_time); ?>
              <?php echo e($today>$start?'complete':'incomplete'); ?>

            </td>
            <td>
              <a href="javaScript:;" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#session_<?php echo e($session->id); ?>">View</a>
              <a href="<?php echo e(route('session.edit',$session->id)); ?>" class="btn btn-info btn-sm">Edit</a>
              <!-- Modal -->
              <div class="modal fade" id="session_<?php echo e($session->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title">Session Detail</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true" style="display:block!important">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body">
                      <table class="table">
                       <tbody>
                        <tr class="warning">
                          <td>Session ID</td><td><?php echo e($session->id); ?></td>
                        </tr>
                       <tr class="warning">
                          <td>Session Time</td><td><?php echo e(date_format(date_create($session->ses_start_time), 'F d,Y h:i a')); ?></td>
                       </tr>
                       <tr class="warning">
                          <td>Session Duration</td><td><?php echo e($session->session_duration); ?> mins</td>
                       </tr>
                       <tr class="warning">
                          <td>Virtual Board</td><td><?php echo e($session->curr_active_board); ?></td>
                       </tr>
                       <tr class="warning">
                          <td>School</td><td><?php echo e(isset($session->school->SchoolName)?$session->school->SchoolName:''); ?></td>
                       </tr>
                       <tr class="warning">
                          <td>District</td><td><?php echo e(isset($session->district->district_name)?$session->district->district_name:''); ?></td>
                       </tr>
                       <tr class="warning">
                          <td>Grade</td><td><?php echo e(isset($session->grade->name)?$session->grade->name:''); ?></td>
                       </tr>
                       <tr class="warning">
                          <td>Lesson</td><td><?php echo e(isset($session->lesson->name)?$session->lesson->name:''); ?></td>
                       </tr>
                       <tr class="warning">
                          <td>Class list of students</td>
                          <td>
                            <?php $__currentLoopData = $session->students(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php echo e($s->first_name.' '.$s->last_name); ?><?php echo e(count($session->students())==$loop->iteration?'':','); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </td>
                       </tr>
                       <tr class="warning">
                          <td>Create Date</td><td><?php echo e(date_format(date_create($session->created_date), 'F d,Y')); ?></td>
                       </tr>
                       <tr class="warning">
                          <td>Session Status</td><td><?php echo e($today>$start?'complete':'incomplete'); ?></td>
                       </tr>
                      </tbody>
                    </table>
                    </div>
                    
                  </div>
                </div>
              </div>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </tbody>
      </table>
    </div>
    
   </div>
   
  </div>
  <!--end::Bottom-->
  
 </div>
 
</div>
<!--end::Container-->
</div>
<!--end::Content-->

 <?php $__env->stopSection(); ?>
 <?php $__env->startSection('js'); ?>
  <?php echo $__env->make('includes.distric_school_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <script src="<?php echo e(asset('assets/plugins/custom/datatables/datatables.bundle.js')); ?>"></script>
  <script>

    $("#session-table").dataTable();
  </script>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('template.container', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/codyivxh/public_html/intervan/resources/views/session/index.blade.php ENDPATH**/ ?>